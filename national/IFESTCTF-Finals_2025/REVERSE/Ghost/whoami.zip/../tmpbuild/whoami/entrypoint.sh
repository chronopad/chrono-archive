#!/bin/sh

(
  sleep 2
  echo "🛑 Simulating malware click..."
  /gosuto
) &

exec /whoami
